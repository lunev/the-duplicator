import{S as r}from"./assets/index-CF1DuhJC.js";chrome.runtime.onInstalled.addListener(e=>{e.reason==="update"&&chrome.storage.sync.set({[r.UPDATES_AVAILABLE]:!0})});
