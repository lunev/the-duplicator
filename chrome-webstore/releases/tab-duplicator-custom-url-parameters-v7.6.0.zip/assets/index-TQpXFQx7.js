const a="Tab Duplicator: Custom URL Parameters",s="Tab Duplicator",t={UPDATES_AVAILABLE:"Updates available",STORAGE_KEY_ROOT:"persist:syncStorage"},A="General";export{a as A,A as G,t as S,s as a};
