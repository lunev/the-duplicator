const a="The Duplicator",s={UPDATES_AVAILABLE:"Updates available",STORAGE_KEY_ROOT:"persist:syncStorage"},A="General";export{a as A,A as G,s as S};
