const A="The Duplicator",a={UPDATES_AVAILABLE:"Updates available"};export{A,a as S};
