const A="The Duplicator",a={UPDATES_AVAILABLE:"Updates available",STORAGE_KEY_ROOT:"persist:syncStorage"};export{A,a as S};
